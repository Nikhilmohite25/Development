// Accept N number from user and return the Smallest number.
#include<stdio.h>
#include<stdlib.h>

int Minimum(int Arr[], int iLength)
{
	int iCnt = 0, Min = Arr[0];
	for(iCnt = 0; iCnt<iLength; iCnt++)
	{
		if(Min>Arr[iCnt])
		{
			Min = Arr[iCnt];
		}
	}
	return Min;
}



int main()
{
	int *ptr = NULL;
	int iSize = 0, iCnt = 0, iRet = 0;
	
	printf("Enter element\n");
	scanf("%d",&iSize);
	
	ptr = (int*) malloc(iSize * sizeof(int));
	
	printf("Enter values\n");
	
	for(iCnt= 0; iCnt<iSize; iCnt++)
	{
		scanf("%d",&ptr[iCnt]);
	}
	
	iRet = Minimum(ptr, iSize);
	
	printf("Smallest Number is %d",iRet);
	
	free(ptr);
	
	return 0;
}
