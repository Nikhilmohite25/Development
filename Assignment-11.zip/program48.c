//Accept N number from user and return difference between largest number and smallest number.

#include<stdio.h>
#include<stdlib.h>

int Difference(int Arr[], int iLength)
{
	int iCnt = 0, iMin = Arr[0], iMax= Arr[0], iDifference = 0;
	for(iCnt = 1; iCnt<iLength; iCnt++)
	{
		if(iMax<Arr[iCnt])
		{
			iMax = Arr[iCnt];
		}
	    else if(iMin>Arr[iCnt])
		{
		    iMin = Arr[iCnt];
		}
		iDifference = iMax - iMin;
	}
	return iDifference;
}



int main()
{
	int *ptr = NULL;
	int iSize = 0, iCnt = 0, iRet = 0;
	
	printf("Enter element\n");
	scanf("%d",&iSize);
	
	ptr = (int*) malloc(iSize * sizeof(int));
	
	printf("Enter values\n");
	
	for(iCnt= 0; iCnt<iSize; iCnt++)
	{
		scanf("%d",&ptr[iCnt]);
	}
	
	iRet = Difference(ptr, iSize);
	
	printf("Difference is %d",iRet);
	
	free(ptr);
	
	return 0;
}
