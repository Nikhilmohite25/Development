#include<stdio.h>
#include<stdlib.h>

int Difference(int Arr[], int iLength)
{
	int iCnt = 0;
	int iSumeven = 0, iSumOdd = 0, iDifference = 0;
	
	for(iCnt = 0; iCnt<iLength; iCnt++)
	{
		if((Arr[iCnt]%2)==0)
		{
			iSumeven  = iSumeven + Arr[iCnt];
		}
		else
		{
			iSumOdd = iSumOdd + Arr[iCnt];
		}
	       iDifference = iSumeven - iSumOdd;
	}
	return iDifference;
}

int main()
{
	int *ptr = NULL;
	int iSize = 0, iCnt = 0, iRet = 0;
	
	
	printf("Enter number of elements\n");
	scanf("%d",&iSize);
	
	ptr = (int*)malloc(iSize * sizeof(int));
	
	printf("enter values\n");
	for(iCnt =0; iCnt<iSize; iCnt++)
	{
	      scanf("%d",&ptr[iCnt]);
	}
	
	iRet = Difference(ptr, iSize);
	
	printf("Difference is %d\n",iRet);
	
	return 0;
}

	