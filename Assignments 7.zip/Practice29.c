//Multiplication of all digits.

#include<stdio.h>

int MultFact(int iNo)
{
	 int iMult = 1;
	 int iDigit = 0;
	   while(iNo>0)
	    {
			 iDigit = iNo % 10;
			 if(iDigit != 0)
			 {
				 iMult=iDigit*iMult;
			 }
		 iNo = iNo / 10;		
		}		 
return iMult;		    
}

int main()
{
	int iValue = 0;
	int iRet = 0;
	
	printf("Enter the number\n");
	scanf("%d",&iValue);
	
	iRet = MultFact(iValue);
	
	printf("%d",iRet);
	return 0;
}