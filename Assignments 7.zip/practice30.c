// Difference Sum of even digit sum of odd digit

#include<stdio.h>
 int CountDiff(int iNo)
 {
   int iDigit=0;
   int iSumEven=0;
   int iSumOdd=0;
   int iDiference;
  if(iNo<0)
  {
    iNo=-iNo;
  }
 while(iNo>0)
 {
   iDigit=iNo%10;

   if(iDigit%2==0)
   {
      iSumEven=iSumEven+iDigit;
   }
  else
   {
      iSumOdd=iSumOdd+iDigit;
   }
   
      iDiference=iSumEven-iSumOdd;

      iNo=iNo/10;
   }
 return iDiference;
}


int main()
{
  int iValue=0;
  int iRet=0;

 printf("Enter a Number\n");
 scanf("%d",&iValue);
 
 iRet=CountDiff(iValue);
 printf("%d",iRet);
 
return 0; 

}