//count frequency of 4 in it.

#include<stdio.h>

int CountFour(int iNo)
{
	int icount=0;
	int iDigit=0;
	
	while(iNo!=0)
	{
		iDigit=iNo%10;
		if(iDigit==4)
		{
			icount++;
		}
		iNo=iNo/10;
	 }
	 return icount;
}
int main()
{
	int iValue=0;
	int iRet=0;
	printf("Enter the number\n");
	scanf("%d",&iValue);
	
	iRet=CountFour(iValue);
	
	printf("count of 4 is : %d",iRet);
	
	return 0;
}